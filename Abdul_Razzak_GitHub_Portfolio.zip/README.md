# Mohammed Abdul Razzak — Cloud Support & Junior DevOps Portfolio

A responsive personal portfolio website built with plain HTML and CSS.

## Publish using GitHub Pages

1. Download and extract this ZIP.
2. Open your GitHub repository: https://github.com/abdulnaazrj-pixel
3. Open the repository you want to use for the portfolio (your existing `myrepo` repository, if that is the one you want to update).
4. Upload `index.html` to the repository's top/root level and commit the changes.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch **main** and folder **/(root)**, then Save.
8. Wait for GitHub Pages to publish, then open the Pages URL shown in Settings → Pages.

## Update before publishing

- Check that your LinkedIn and GitHub profile links are correct.
- Review the project descriptions and keep them aligned with what you personally completed.
- This version does not publish your phone number. It includes your email address as a contact option.
